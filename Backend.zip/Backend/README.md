# Infizest-Employee-Tracker
This the Employee Management Sys Designed by Oishik Dutta and Team. Tech stacks - React and Node.js
